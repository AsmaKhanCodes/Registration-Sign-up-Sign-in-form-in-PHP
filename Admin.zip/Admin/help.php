$nameErr = $emailErr = $passwordErr = $cpassword= "";
    $username = $email = $password = "";
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
      }

   


     if (empty($_POST["username"])) {
        $nameErr = "Name is required";
        header('Location: register.php');
      } else {
        $username = test_input($_POST["username"]);
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z-' ]*$/",$username)) {
          $nameErr = "Only letters and white space allowed";
          header('Location: register.php');
        }
      }
      
      if (empty($_POST["email"])) {
        $emailErr = "Email is required";
      } else {
        $email = test_input($_POST["email"]);
        // check if e-mail address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $emailErr = "Invalid email format";
        }
      }
      if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
      }else {
        $password = test_input($_POST["password"]);
        // Less than 6 characters
        if (strlen($password < 6 )) {
          $nameErr = "The Password must be atleast 6 characters in length";
        }
      }
      if (empty($_POST["cpassword"])) {
        $passwordErr = "Confirm Password is required";
      }
  